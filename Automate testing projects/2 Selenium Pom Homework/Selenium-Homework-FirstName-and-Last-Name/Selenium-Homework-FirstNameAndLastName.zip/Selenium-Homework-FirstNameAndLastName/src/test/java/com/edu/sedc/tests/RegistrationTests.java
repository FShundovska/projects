package com.edu.sedc.tests;

import com.edu.sedc.pages.LoginPage;
import com.edu.sedc.pages.RegistrationPage;
import com.edu.sedc.utils.Data;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Element;

public class RegistrationTests extends BaseTests {

    @Test
            (dataProvider = "registrationData", dataProviderClass = Data.class)
    public void registrationTest(String firstname, String lastname, String username, String password) {

        RegistrationPage registrationPage = new RegistrationPage(driver, wait);
        js.executeScript("arguments[0].scrollIntoView();", Element);
        registrationPage.clickNewUser();
        registrationPage.populateRegistrationFields(firstname, lastname, username, password);

        registrationPage.clickRegister();

        // Assert "Please Verify Recaptcha to register" message
        String expectedRecaptchaMessage = "Please Verify Recaptcha to register";
        String actualRecaptchaMessage = registrationPage.getRecaptchaMessage();
        Assert.assertEquals(actualRecaptchaMessage, expectedRecaptchaMessage,
                "Unexpected message for Recaptcha validation");
    }
}



