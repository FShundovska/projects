package com.edu.sedc.tests;


import com.edu.sedc.pages.LinksPages;
import com.edu.sedc.tests.BaseTests;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LinksTests extends BaseTests {

    @Test
    public void testLinksPages (){

        LinksPages linksPages = new LinksPages(driver, wait);
        linksPages.navigateToLinksUrl();
        linksPages.created();
        linksPages.noContent();
        linksPages.moved();
        linksPages.badRequest();
        linksPages.unauthorized();
        linksPages.forbidden();
        linksPages.notFound();
        /*linksPages.open();
        linksPages.clickAllLinks();*/

        Assert.assertEquals(linksPages.getCreatedMessage(), "Expected Created message: Link has responded with staus 201 and status text Created");
        Assert.assertEquals(linksPages.getNoContentMessage(), "Expected No Content message: Link has responded with staus 204 and status text No Content");
        Assert.assertEquals(linksPages.getMovedMessage(), "Expected Moved message: Link has responded with staus 301 and status text Moved Permanently");
        Assert.assertEquals(linksPages.getBadRequestMessage(), "Expected Moved message: Link has responded with staus 400 and status text Bad Request");
        Assert.assertEquals(linksPages.getUnauthorizedMessage(), "Expected Moved message: Link has responded with staus 401 and status text Unauthorized");
        Assert.assertEquals(linksPages.getForbiddenMessage(), "Expected Moved message: Link has responded with staus 403 and status text Forbidden");
        Assert.assertEquals(linksPages.getNotFoundMessage(), "Expected Moved message: Link has responded with staus 404 and status text Not Found");




        /*String actualMessage = linksPages.getMovedMessage(link_text);
        Assert.assertEquals(actualMessage, expected_message, "Unexpected message for link: " + link_text);*/

        }

    }

