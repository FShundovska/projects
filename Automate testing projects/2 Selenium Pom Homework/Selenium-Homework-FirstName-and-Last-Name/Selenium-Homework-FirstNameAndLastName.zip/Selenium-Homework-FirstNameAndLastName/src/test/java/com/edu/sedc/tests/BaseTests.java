package com.edu.sedc.tests;

import com.edu.sedc.pages.LoginPage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Element;

public class BaseTests {

    public WebDriver driver;
    public WebDriverWait wait;
    private LoginPage loginPage;
    final String BASE_URL = "https://demoqa.com/login";
    //private int duration = 20;

    JavascriptExecutor js;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        //wait = new WebDriverWait(driver, Duration.ofSeconds(duration));
        driver.get(BASE_URL);
        driver.manage().window().maximize();
        loginPage = new LoginPage(driver, wait);
        //This will scroll the page till the element is found
        js.executeScript("arguments[0].scrollIntoView();", Element);



    }

    /*@AfterMethod
    public void tearDown() {
        driver.quit();
    }*/

}
