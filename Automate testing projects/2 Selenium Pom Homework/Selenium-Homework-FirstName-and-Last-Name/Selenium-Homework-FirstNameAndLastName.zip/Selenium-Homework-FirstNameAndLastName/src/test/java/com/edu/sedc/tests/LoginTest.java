package com.edu.sedc.tests;

import com.edu.sedc.pages.LoginPage;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Element;

public class LoginTest extends BaseTests {


    @Test
    public void testInvalidLogin(String username, String password) {

        // Scroll down the page
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 250)");

        LoginPage loginPage = new LoginPage(driver, wait);
        /*JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView();", Element);*/
        loginPage.enterCredentials("invaliduser", "wrongpassword");
        loginPage.clickLogin();

        String actualErrorMessage = loginPage.getErrorMessage();
        Assert.assertEquals(actualErrorMessage, "Invalid Username or Password");

        driver.quit();
    }

}
