package com.edu.sedc.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationPage {
    WebDriver driver;
    WebDriverWait wait;

    /*WebDriverWait wait = new WebDriverWait(driver, 10);*/
    WebElement newUserButton;
   
    public RegistrationPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }
    public By newUserInput = By.xpath("//div//div//div//div//div//div//div[2]//button[1]");
    final private By firstNameField = By.id("firstname");
    final private By lastNameField = By.id("lastname");
    final private By usernameField = By.id("userName");
    final private By passwordField = By.id("password");
    final private By registerButton = By.id("register");
    final private By recaptchaMessage = By.id("recaptchaMessage");


    public void clickNewUser() {
        driver.findElement(newUserInput).click();
    }

    public void populateRegistrationFields(String firstname, String lastname, String username, String password) {
        driver.findElement(firstNameField).sendKeys(firstname);
        driver.findElement(lastNameField).sendKeys(lastname);
        driver.findElement(usernameField).sendKeys(username);
        driver.findElement(passwordField).sendKeys(password);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("newUser")));
        newUserButton.click();

    }

    public void clickRegister() {

        driver.findElement(registerButton).click();
    }

    public String getRecaptchaMessage() {

        return driver.findElement(recaptchaMessage).getText();
    }
}

