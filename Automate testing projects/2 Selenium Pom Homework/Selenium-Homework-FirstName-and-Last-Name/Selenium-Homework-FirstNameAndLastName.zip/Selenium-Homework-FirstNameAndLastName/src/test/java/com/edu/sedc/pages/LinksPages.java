package com.edu.sedc.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.util.List;

public class LinksPages {
    WebDriver driver;
    WebDriverWait wait;

    public LinksPages(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public void navigateToLinksUrl() {
        driver.navigate().to("https://demoqa.com/links");
    }

    private By createdMessageLocator = By.xpath("//*[@id=\"created\"]");
    private By noContentMessage = By.xpath("//*[@id=\"no-content\"]");
    private By movedMessage = By.xpath("//*[@id=\"moved\"]");
    private By badRequestMessage = By.xpath("//*[@id=\"bad-request\"]");
    private By unauthorizedMessage = By.xpath("//*[@id=\"unauthorized\"]");
    private By forbiddenMessage = By.xpath("//*[@id=\"forbidden\"]");
    private By notFoundMessage  = By.xpath("//*[@id=\"invalid-url\"]");

    private final By headerText = By.tagName("h5");

    public void created() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("created"))).sendKeys("Link has responded with staus 201 and status text Created");
    }
    public void noContent() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("no-content"))).sendKeys("Link has responded with staus 204 and status text No Content");
    }
    public void moved() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("moved"))).sendKeys("Link has responded with staus 301 and status text Moved Permanently");
    }
    public void badRequest() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("bad-request"))).sendKeys("Link has responded with staus 400 and status text Bad Request");
    }
    public void unauthorized() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("unauthorized"))).sendKeys("Link has responded with staus 401 and status text Unauthorized");
    }
    public void forbidden() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("forbidden"))).sendKeys("Link has responded with staus 403 and status text Forbidden");
    }
    public void notFound() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("invalid-url"))).sendKeys("Link has responded with staus 404 and status text Not Found");
    }

    public String getCreatedMessage() {
        WebElement createdMessageElement = wait.until(ExpectedConditions.presenceOfElementLocated(createdMessageLocator));
        return createdMessageElement.getText();
    }
    public String getNoContentMessage() {
        WebElement createdMessageElement = wait.until(ExpectedConditions.presenceOfElementLocated(noContentMessage));
        return createdMessageElement.getText();
    }
    public String getMovedMessage() {
        WebElement createdMessageElement = wait.until(ExpectedConditions.presenceOfElementLocated(movedMessage));
        return createdMessageElement.getText();
    }
    public String getBadRequestMessage() {
        WebElement createdMessageElement = wait.until(ExpectedConditions.presenceOfElementLocated(badRequestMessage));
        return createdMessageElement.getText();
    }
    public String getUnauthorizedMessage() {
        WebElement createdMessageElement = wait.until(ExpectedConditions.presenceOfElementLocated(unauthorizedMessage));
        return createdMessageElement.getText();
    }
    public String getForbiddenMessage() {
        WebElement createdMessageElement = wait.until(ExpectedConditions.presenceOfElementLocated(forbiddenMessage));
        return createdMessageElement.getText();
    }
    public String getNotFoundMessage() {
        WebElement createdMessageElement = wait.until(ExpectedConditions.presenceOfElementLocated(notFoundMessage));
        return createdMessageElement.getText();
    }




    public void clickAllLinksAndAssertMessages() {
        List<WebElement> links = driver.findElements(By.tagName("a"));
        for (WebElement link : links) {
            link.click();
            String message = driver.findElement(By.id("message")).getText();
            System.out.println("Link: " + link.getText() + " - Message: " + message);
        }


        /*@FindBy(xpath = "//a[contains(@href,'api')]")
        private List<WebElement> apiLinks;*/


    }

}
