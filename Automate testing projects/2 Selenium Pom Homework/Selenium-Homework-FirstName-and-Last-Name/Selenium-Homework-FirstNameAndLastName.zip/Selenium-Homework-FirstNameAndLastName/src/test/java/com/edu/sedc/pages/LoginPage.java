package com.edu.sedc.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;


public class LoginPage {
    WebDriver driver;
    WebDriverWait wait;

    final private By usernameField = By.id("username");
    /*@FindBy(id = "username")
    private WebElement usernameField;*/

    final private By passwordField = By.id("password");
    /*@FindBy(id = "password")
    private WebElement passwordField;*/
    final private By loginButton = By.id("login");
    /*@FindBy(id = "login")
    private WebElement loginButton;*/
    final private By errorMessage = By.id("error");

    public LoginPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public void enterCredentials(String username, String password) {
        driver.findElement(usernameField).sendKeys(username);
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickLogin() {
        driver.findElement(loginButton).click();
    }

    public String getErrorMessage() {
        return driver.findElement(errorMessage).getText();
    }

}





