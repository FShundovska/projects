package com.edu.sedc.tests;

import com.edu.sedc.pages.FilterByComputerNameInputPage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FilterByComputerNameInputTests extends BaseTests {

    @Test
    public void testFilterByComputerName() {

        FilterByComputerNameInputPage filterPage = new FilterByComputerNameInputPage(driver, wait);
        filterPage.enterFilterText("Filter by name");
        filterPage.clickFilterByNameButton();


        driver.findElement(By.cssSelector("input#searchbox"));

        driver.findElement(By.id("searchsubmit")).click();

        String expectedHeaderText = "Computer database";
        String headerText = driver.findElement(By.cssSelector("h1")).getText();

        Assert.assertEquals(headerText, expectedHeaderText);
        Assert.assertEquals(headerText, "Computer database");

        Assert.assertEquals(headerText, expectedHeaderText, "Header text does not match expected value");
    }
}
