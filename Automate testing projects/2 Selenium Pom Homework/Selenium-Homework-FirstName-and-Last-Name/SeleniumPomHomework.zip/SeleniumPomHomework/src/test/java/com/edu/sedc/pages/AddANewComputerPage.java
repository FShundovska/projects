package com.edu.sedc.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddANewComputerPage {
    WebDriver driver;
    WebDriverWait wait;

    private By addNewComputerButton = By.id("add");
    private By computerName = By.id("name");
    private By introducedDate = By.id("introduced");
    private By discontinuedDate = By.id("discontinued");
    private By createComputerButton = By.xpath("//input[@type='submit']");

    public AddANewComputerPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public void clickAddNewComputerButton(){
        driver.findElement(addNewComputerButton).click();
    }
    public void navigateToAddANewComputer() {
        driver.navigate().to("https://computer-database.gatling.io/computers/new");
    }
    public void enterComputerName(String name) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(computerName)).sendKeys(name);
    }

    public void dateOfIntroduce(String date1) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(introducedDate)).sendKeys(date1);
    }

    public void dateOfDiscontinue(String date2) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(discontinuedDate)).sendKeys(date2);
    }

    public void clickCreateComputerButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(createComputerButton)).click();
    }


}
