package com.edu.sedc.tests;

import com.edu.sedc.pages.AddANewComputerPage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AddANewComputerTests extends BaseTests {

    @Test
    public void testAddANewComputerName() {

        AddANewComputerPage addANewComputerPage = new AddANewComputerPage(driver, wait);

        addANewComputerPage.clickAddNewComputerButton();
        addANewComputerPage.navigateToAddANewComputer();
        addANewComputerPage.enterComputerName("ComputerTest");
        addANewComputerPage.dateOfIntroduce("2024-03-09");
        addANewComputerPage.dateOfDiscontinue("2025-03-09");
        addANewComputerPage.clickCreateComputerButton();

    }

}
