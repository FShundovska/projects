package com.edu.sedc.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FilterByComputerNameInputPage {
    WebDriver driver;
    WebDriverWait wait;

    private final By filterInput = By.cssSelector("#searchbox");
    private final By filterButton = By.id("searchsubmit");
    private final By headerText = By.tagName("h1");

    public FilterByComputerNameInputPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public void enterFilterText(String filterText) {
        driver.findElement(filterInput).sendKeys(filterText);
    }

    public void clickFilterByNameButton() {
        driver.findElement(filterButton).click();
    }

    public String getHeaderText() {
        return driver.findElement(headerText).getText();
    }
}



