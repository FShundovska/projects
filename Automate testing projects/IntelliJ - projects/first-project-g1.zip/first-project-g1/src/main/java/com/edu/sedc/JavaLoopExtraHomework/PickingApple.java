package com.edu.sedc.JavaLoopExtraHomework;

public class PickingApple {

    public static void main(String[] args) {

        int basketCapacity = 23;

        int[] applesToPick = {100, 230, 470};

        for (int apples : applesToPick) {
            int basketsNeeded = (int) Math.ceil((double) apples / basketCapacity);
            System.out.println("For " + apples + " apples, you'll need " + basketsNeeded + " baskets.");
        }
    }

}

