package com.edu.oop.inheritance;

public class TestInheritance {

    public static void main(String[] args) {
        Dog pudla = new Dog ();
        pudla.bark();
        pudla.eat();


        //Multilevel inheritance
        BabyDog babyDog1 = new BabyDog();
        babyDog1.weeping(); // -. si ja koristime metodatata od samata klasa
        babyDog1.bark(); // -.si ja koristime bidejki BabyDog nasleduva od Dog
        babyDog1.eat(); //-. Dog klasata nasleduva od Animal

        //Hierarchical Inheritance
        Cat cat1 = new Cat();
        cat1.meowing();
        cat1.eat();



    }



}
