package com.edu.sedc.Javahomework6;

public class BiggestSmallestElement {
    public static void main(String[] args) {

        int[] numbers = {2, 4, 23, 100, 66, 11, 2602, 36};
        int largest = findLargest(numbers);
        int smallest = findSmallest(numbers);

        System.out.println("Largest element: " + largest);
        System.out.println("Smallest element: " + smallest);
    }
    public static int findLargest(int[] arr) {
        int largest = arr[0];
        for (int num : arr) {
            if (num > largest) {
                largest = num;
            }
        }
        return largest;
    }
    public static int findSmallest(int[] arr) {
        int smallest = arr[0];
        for (int num : arr) {
            if (num < smallest) {
                smallest = num;
            }
        }
        return smallest;
    }
}


