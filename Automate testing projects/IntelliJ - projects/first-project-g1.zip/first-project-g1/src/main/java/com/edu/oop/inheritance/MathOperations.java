/*package com.edu.oop.inheritance;

public class MathOperations {

    public double division(double num1, double num2) {
        if (num2 != 0) {
            return num1 / num2;
        } else {
            System.out.println("Error: Division by zero!");
            return Double.NaN;
        }
    }

    public double multiplication(double num1, double num2) {
        return num1 * num2;
    }

}


public  double podeleno(double broj1, double broj2){
    return broj1/broj2;
}

public static double pomnozeno(double broj1, double broj2){
    return broj1*broj2;
}


}*/