package com.edu.sedc;
public class ConditionalFlowStatement {
    public static void main(String[] args) {

      /*if (20>18){
          System.out.println("20 is greater than 18");
      }

      int x = 20;
      int y = 18;

      if(x>y) {
          System.out.println("x is greater than y");
      }*/

        //IF - ELSE
        /*int time = 20;
        if (time < 18) {
            System.out.println("Good day");
        } else {
            System.out.println("Good evening");
        }*/

        //IF -ELSE IF
        /*int time = 18;
        if (time<10){
            System.out.println("Good Morning");
        } else if (time<20){
            System.out.println("Good day");
        } else {
            System.out.println("Good evening");
        }*/

        //NESTED IF
        /*double prosek = 5.2;
        char ocenka = 'A';

        if (ocenka=='A'){
            if (prosek>5){
                System.out.println("Studentot ima ocenka A i moze da ima stipendija");
            } else {
            System.out.println("Studentot ima ocenka A i ne moze da ima stipendija");
            }

        } else {
            System.out.println("Studentot nema ocenka 'A");
        }*/

        /*int personsAge = 20;
        if (personsAge > 18) {
            System.out.println("Liceto e polnoletno");
        } else {
            System.out.println("Liceto ne e polnoletno");
        }*/

        /*int personsAge = 25;
        if (personsAge<18){
            System.out.println("persons under 18");
        } else if (personsAge >= 18 && <= 40){
            System.out.println("persons between 18 and 40");
        }
        else {
            System.out.println(" persons older than 40");
        }*/

        //Switch statement

        /*String browser = "Chrome";
        switch (browser) {
            //vo ovoj del gi pisuvame caseovite
            case "Chrome":
                //kodot koj sto teba da se izvrsi
                System.out.println("Chrome browser started");
                break;
            case "Firefox":
                System.out.println("Firefox browser started");
                break;
            default:
                System.out.println("Invalid browser is supported");
                break;
        }*/

    }
}