package com.edu.oop;

public class Car {

    public String carModel; //ni se narekuvaat varijabli koi se instanciraat

    public int yearOfProduction;

    public String carBrend;

    public static String exportCountry = "Germany"; // klasna varijabla bidejki ja ima pretstavkata static

    public Car(){
        //Konstruktor
    }
    public void accelerate(){
        System.out.println("Car is accelerating");
    }

    public void stop(){
        System.out.println("Car is stopping");
    }

    public void start(){
        System.out.println("Car is starting");
    }

    public static void initiateInssurance(){
        System.out.println("Car can be insured");
    }

    public void popolniGiInputite(){
        popolniInputEden();
        popolniInputDva();
        popolniInputTri();
    }
    private void popolniInputEden(){
        System.out.println("Input 1 e popolnet");
    }

    private void popolniInputDva(){
        System.out.println("Input 2 e popolnet");
    }

    private void popolniInputTri(){
        System.out.println("Input 3 e popolnet");
    }
}
