package com.edu.sedc.JavaIfElseExtraHomeworkAT06;

public class CompareDifference {

    public static void main(String[] args) {
        int x = 10;
        int y = 5;

        if (x > y) {
            System.out.println("x is bigger than y.");
        } else if (x < y) {
            System.out.println("x is smaller than y.");
        } else {
            System.out.println("x and y are the same.");
        }

        int difference = Math.abs(x - y);
        System.out.println("Difference between x and y: " + difference);
    }

}
