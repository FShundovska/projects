package com.edu.oop.inheritance;

public class Cat extends Animal {

    void meowing(){
        System.out.println("Meowing");
    }
}
