package com.edu.oop.inheritance;

public class ExersizePerson {

    public static void main(String[] args) {
        Person defaultPerson = new Person();
        defaultPerson.printFullName();

        Person customPerson = new Person("Fani", "Shundovska");
        customPerson.printFullName();

    }
}
