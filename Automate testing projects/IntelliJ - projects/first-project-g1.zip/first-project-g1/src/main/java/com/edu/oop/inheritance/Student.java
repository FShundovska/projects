package com.edu.oop.inheritance;

public class Student {



    public static void listStudentsWith3Letters(String[] students) {
        for (int i = 0; i < students.length; i++) {
            if (students[i].length() == 3) {
                System.out.println(students[i]);
            }
        }
    }

}
