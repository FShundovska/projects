package com.edu.sedc;

public class JavaHomework5 {
    public static void main(String[] args) {

        /*String[] myStringArray = new String[5];
        int i = 0;
        while (i < myStringArray.length) {
            myStringArray[i] = "Element " + (i + 1);
            i++;
        }
        System.out.println("Elements in the array:");
        for (String element : myStringArray) {
            System.out.println(element);
        }*/


        /*double[] array = {1.2, 3.4, 5.6, 7.8, 9.0};
        double sum = 0;
        for (double element : array) {
            sum += element;
        }
        double average = sum / array.length;
        System.out.println("The sum is: " + sum);
        System.out.println("The average is: " + average);*/


        /*int[] array = new int[20];
        for (int i = 0; i < array.length; i++) {
            array[i] = i + 1;
        }
        for (int i = array.length - 1; i >= 0; i--) {
            System.out.println(array[i]);
        }*/


        /*int [] field = {2, 20, 3, 13, 15, 3, 9, 10, 1, 5, 8};
        int oddCount = 0;
        for (int element : field) {
            if (element % 2 != 0) {
                oddCount++;
            }
        }
        System.out.println("The number of odd elements in the array is: " + oddCount);*/


        /*int[] myArray = {10, 21, 34, 45, 56}; // Example values

        System.out.println("Odd numbers in the given array are:");
        for (int i = 0; i < myArray.length; i++) {
            if (myArray[i] % 2 != 0) {
                System.out.println(myArray[i]);
            }
        }*/

        /*int[] array = {10, 20, 30, 40, 10};
        if (array.length >= 2) {
            boolean result = array[0] == array[array.length - 1];
            System.out.println(result);
        } else {
            System.out.println("Array length less than 2.");
        }*/




    }
}
