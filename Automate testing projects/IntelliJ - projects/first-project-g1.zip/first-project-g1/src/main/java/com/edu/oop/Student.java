package com.edu.oop;

public class Student {

    public int id;

    public String fullName;

    public Student(int id, String fullName){
        this.fullName=fullName;
        this.id=id;
        //so this se odnesuva na davanje referenca deka vrednosta na argumentot od konstruktor
        //ke se odnesuva na vrednostite na varijablite.

    }

    public Student() {

    }


    public void displayStudent(){
        System.out.println("Student full name is " + fullName + " " + "with id " + id);
    }
}
