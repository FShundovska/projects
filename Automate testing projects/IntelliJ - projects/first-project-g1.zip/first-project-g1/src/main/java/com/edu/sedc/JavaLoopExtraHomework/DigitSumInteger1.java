package com.edu.sedc.JavaLoopExtraHomework;

import java.util.Scanner;

public class DigitSumInteger1 {
    public static int calculateDigitSum(int number) {
        int sum = 0;

        while (number != 0) {
            sum += number % 10;
            number /= 10;
        }
        return sum;
    }

    public static void main(String[] args) {
        int inputNumber = 987654321;
        int sumOfDigits = calculateDigitSum(inputNumber);
        System.out.println("Sum of digits of " + inputNumber + " is: " + sumOfDigits);
    }
}