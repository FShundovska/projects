package com.edu.sedc.JavaHomework7.package2question1;

import com.edu.sedc.JavaHomework7.package1question1.Access1;

public class Access3 {

    public static void main(String[] args) {
        Access1 access10 = new Access1();

        access10.allClassesVariable = 30;

        System.out.println("Value of access1Variable in Access3: " + access10.allClassesVariable);


    }
}



