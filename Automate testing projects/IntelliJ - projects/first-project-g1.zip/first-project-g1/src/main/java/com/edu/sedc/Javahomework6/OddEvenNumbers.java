/*package com.edu.sedc.Javahomework6;


public class OddEvenNumbers {

    public static void main(String[] args) {

        public static void main (String[]args){

            int[] numbers = {2, 4, 23, 100, 66, 11, 2602, 36};

            static void returnOdd(int[] arrayOfNumbers) {
                System.out.println("Odds:");
                for (int i = 0; i < arrayOfNumbers.length; i++) {
                    if (arrayOfNumbers[i] % 2 != 0) {
                        System.out.print(arrayOfNumbers[i] + " ");
                    }
                }


                static void returnEven ( int[] arrayOfNumbers1){
                    System.out.println("\nEvens:");
                    for (int i = 0; i < arrayOfNumbers1.length; i++) {
                        if (arrayOfNumbers1[i] % 2 == 0) {
                            System.out.print(arrayOfNumbers1[i] + " ");
                        }
                    }
            returnOdd(numbers);
            returnEven(numbers);

        }*/





        /*int[] numbers = {2, 4, 23, 100, 66, 11, 2602, 36};
        int oddResult = findOddNumber(numbers);
        int evenResult = findEvenNumber(numbers);

        System.out.println("Odd number: " + oddResult);
        System.out.println("Even number: " + evenResult);
    }
    public static int findOddNumber(int[] arr) {
        for (int num : arr) {
            if (num % 2 != 0) {
                return num;
            }
        }
        return -1;
    }
    public static int findEvenNumber(int[] arr) {
        for (int num : arr) {
            if (num % 2 == 0) {
                return num;
            }
        }
        return -1;

        for (int c = 0; c < numbers.length; c++) {
            if (numbers[c] % 2 == 0) {
                System.out.println(numbers[c] + " is even");
            } else {
                System.out.println(numbers[c] + " is odd");
            }
        }*/



