package com.edu.sedc.Javahomework6;

public class Sum {

    public static void main(String[] args) {

        int num1 = 5;
        int num2 = 7;

        int sum = calculateSum(num1, num2);

        if (sum > 10) {
            System.out.println("Sum is bigger than 10");
        } else if (sum < 10) {
            System.out.println("Sum is smaller than 10");
        } else {
            System.out.println("Sum is equal to 10");
        }
    }

    public static int calculateSum(int a, int b) {
        return a + b;
    }
}


