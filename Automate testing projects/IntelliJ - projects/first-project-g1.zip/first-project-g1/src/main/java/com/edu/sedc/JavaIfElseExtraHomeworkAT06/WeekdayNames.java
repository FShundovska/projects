package com.edu.sedc.JavaIfElseExtraHomeworkAT06;

import java.util.Scanner;

public class WeekdayNames {

    public static void main(String[] args) {

        int day = 4;
        String dayOfWeek = Integer.toString(day);

        switch (dayOfWeek) {
            case "1":
                System.out.println("Monday");
                break;
            case "2":
                System.out.println("Tuesday");
                break;
            case "3":
                System.out.println("Wednesday");
                break;
            case "4":
                System.out.println("Thursday");
                break;
            case "5":
                System.out.println("Friday");
                break;
            case "6":
                System.out.println("Saturday");
                break;
            case "7":
                System.out.println("Sunday");
                break;
            default:
                System.out.println("Invalid input");
                break;
        }

        Scanner sc = new Scanner(System.in);
        System.out.print("The day number is: 4");
        int dayNumber = sc.nextInt();

        String[] weekdays = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

        if (dayNumber >= 1 && dayNumber <= 7) {
            System.out.println("Weekday: " + weekdays[dayNumber - 1]);
        } else {
            System.out.println("Invalid input. Please enter a number between 1 and 7.");
        }
    }
}



