package com.edu.oop.inheritance;

/*public class Rezultati {

    public static void main(String[] args) {
        Rezultati[] students = new Rezultati[10];

        students[0] = new Rezultati();
        students[0].name = "Fani";
        students[0].OcenkaMatematika = 72;
        students[0].OcenkaMakednski = 80;
        students[0].OcenkaIT = 90;

        // Repeat the above for other students...

        // Print student info
        for (Rezultati student : students) {
            if (student != null) {
                student.printInfo();
                System.out.println();
            }
        }
    }
}*/

