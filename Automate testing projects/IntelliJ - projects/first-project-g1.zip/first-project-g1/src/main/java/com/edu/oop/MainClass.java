package com.edu.oop;

public class MainClass {

    public static void main(String[] args) {
        /*Car japaneseCar = new Car(); //Car () ni pretstavuva Konstruktor
        japaneseCar.carBrend = "Toyota";
        japaneseCar.yearOfProduction = 2024;
        japaneseCar.carModel = "Corola";

        japaneseCar.accelerate();

        System.out.println(japaneseCar.carBrend);*/

        Car germanCars = new Car(); //-> KONSTRUKTOR
        germanCars.carBrend = "Mercedes";
        germanCars.yearOfProduction = 2022;
        germanCars.carModel = "CLE";

        germanCars.stop();

        /*System.out.println(germanCars.carBrend);

       //povikuvanje direktno od klasa bez kreiranje na objekt
        System.out.println(Car.exportCountry);
        Car.initiateInssurance();
        germanCars.popolniGiInputite();*/

        Student fani1 = new Student(123, "Fani Shundovska");
        fani1.displayStudent();

        Student martina = new Student(333, "Martina Veljanoska");
        martina.displayStudent();

        Student fani = new Student();
        fani.id = 555;
        fani.fullName = "Fani Shundovska";
        fani.displayStudent();




    }

}
