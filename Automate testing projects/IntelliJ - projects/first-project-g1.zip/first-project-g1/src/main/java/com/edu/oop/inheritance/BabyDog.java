package com.edu.oop.inheritance;

public class BabyDog extends Dog {

    void weeping(){
        System.out.println("Weeping");
    }
}
