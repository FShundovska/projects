package com.edu.sedc.Javahomework6;

public class MyClassJava1 {
    public static void main(String[] args) {

        String myName = "Fani";
        myStringMethod.printName(myName);

    }
}
