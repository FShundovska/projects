package com.edu.sedc.JavaHomework7.package1question1;

public class Access2 {

    public static void main(String[] args) {

        Access1 access1O = new Access1();
        access1O.package1Variable = 10;
        access1O.allClassesVariable = 20;
        System.out.println("Value of allClassesVariable: " + access1O.allClassesVariable);
        System.out.println("Value of package1Variable: " + access1O.package1Variable);


    }
}
