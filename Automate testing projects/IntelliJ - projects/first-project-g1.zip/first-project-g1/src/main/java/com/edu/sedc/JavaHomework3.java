package com.edu.sedc;

public class JavaHomework3 {
    public static void main(String[] args) {

        /*int a = 10;
        System.out.println(a + 1);
        a++;
        System.out.println(a);
        a = a + 1;
        System.out.println(a);*/

        /*int a = 10;
        a--;
        System.out.println(a);
        a = a - 1;
        System.out.println(a);*/

        /*int x = 1;
        int y = 0;

        if (y e pogolemo od 0)
        { x = 1; }
        sistem out print line (x)
        if(x>y) {
            System.out.println("x is greater than y");}*/


       /*int x = 5;
        if (x > 0 && x % 2 == 1) {
            System.out.println(true);
        }*/

        /*boolean condition1 = true;
        boolean condition2 = false;
        if (condition1 || condition2) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }*/

        /*double variable = 85.0;

        if (variable >= 80 && variable <= 90) {
            variable += 5;
            System.out.println("The variable value is " + variable);
        }
        else if (variable < 80) {
            variable += 3;
            System.out.println("The variable value is " + variable);
        }
        else {
            System.out.println("The variable value isn't changed");
        }*/

        /*int x = 10;
        int y = 9;
        System.out.println(x > y);*/





    }
}








