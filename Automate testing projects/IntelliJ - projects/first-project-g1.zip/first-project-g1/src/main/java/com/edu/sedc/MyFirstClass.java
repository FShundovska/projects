package com.edu.sedc;

public class MyFirstClass {

    public static void main(String[] args) {

        System.out.println("Hello World");

        // VARIJABLI
    /*
        String text = "Hello";
        int broj = 2;
        float drugBroj =19.2f;
        double decimalenBroj = 15.5;
        char bukva = 'A';
        boolean vistina = true;

        System.out.println(bukva);
        */

        //Declaring Variable
        //int myNumber;

        //Assigning value (dodavvanje vrednost na varijabla)

        //myNumber = 7;

        //Inittializing a variable (Inicijalizacija na varijabla)

        //String message = "Hello World";

        //Declaring the same variables of same type

        //int x, y, z; // Declaring more variables of same type

        //int p=20, u=30, a=10; //Inittializing more variables of same type

        //Overriding the value (Menuvanje na vrednosta)

       /* int myNumber = 10;
        System.out.println(myNumber);

        myNumber = 20;
        System.out.println(myNumber);

        final int broj = 32;
        System.out.println(broj);*/

        //byte smallNumber = 127;//

        //Automatic casting
        /*int myInt = 9;
        double myDouble = myInt;

        System.out.println(myInt);
        System.out.println(myDouble);*/

        /*Manual casting
        double myDouble = 9.78;
        int myInt = (int) myDouble;

        System.out.println(myDouble);
        System.out.println(myInt);*/









    }


}
