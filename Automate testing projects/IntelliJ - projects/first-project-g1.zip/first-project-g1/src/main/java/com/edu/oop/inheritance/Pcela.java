package com.edu.oop.inheritance;

public class Pcela {

    public void leta () {
        System.out.println("Pcelata leta");
    }

    public void polen (){
        System.out.println("Pcelata sobira polen");
    }

}
