package com.edu.sedc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class XPathHomework {


    String url = "https://practice.automationtesting.in/my-account/";

    @Test
    public void XpathHomework(){

        WebDriver driver = new ChromeDriver();
        driver.get(url);

        //Username Input
        driver.findElement(By.xpath("//input[@id='username']"));

        //Password Input
        driver.findElement(By.xpath("//input[@id='password']"));

        //Login Button
        driver.findElement(By.xpath("//input[@name='login']"));

        //Remember me Checkbox
        driver.findElement(By.xpath("//input[@id='rememberme']"));

        //Lost your password
        driver.findElement(By.xpath("//a[contains(text(), 'Lost your password?')]"));

        //E-mail address input
        driver.findElement(By.xpath("//input[@id='reg_email']"));

        //Password input (for Registration)
        driver.findElement(By.xpath("//input[@id='reg_password']"));

        //Register Button
        driver.findElement(By.xpath("//input[@name='register']"));

    }


    @Test
    public void XPathHomework1(){
        WebDriver driver = new ChromeDriver();
        driver.get("https://practice.automationtesting.in/shop/");

        //Accordion number 5 Home page-Arrivals-Images-Reviews
        driver.findElement(By.xpath("//*[@id=\"accordion-222-sub_row_1-0-1-0-0\"]/ul/li[5]/div[1]/a/text()[3]"));

        //In Accordion number 18 Click on Shop Menu text
        driver.findElement(By.xpath("//*[@id=\"accordion-222-sub_row_1-0-1-0-0\"]/ul/li[18]/div[2]/p/text()[3]"));

    }

    @Test
    public void XPathHomework2(){
        WebDriver driver = new ChromeDriver();

        driver.get("https://practice.automationtesting.in/shop/");


        //Filter Button
        driver.findElement(By.xpath("//button[contains(.,'Filter')]"));

        //AT site LinkText (Link at the bottom of the page  - > Automation Practice Site)
        driver.findElement(By.xpath("//a[contains(., 'Automation Practice Site')]"));


    }


}
