package com.edu.sedc;

import org.testng.annotations.*;

public class TestNgClass {

    @Test (priority = 2)
    public void testCase1(){
        System.out.println("Test Case 1");
    }

    @Test(priority = 1)
    public void testCase2(){
        System.out.println("Test Case 2");
    }

    @BeforeMethod
    public void beforeMethod(){
        System.out.println("Before Method");
        //se izvrshuva pred sekoj test
    }

    @AfterMethod
    public void afterMethod(){
        System.out.println("After Method");
        //se izvrshuva posle sekoj test
    }

    @BeforeTest
    public void beforeTest(){
        System.out.println("Before test method");
    }

    @AfterTest
    public void afterTest(){
        System.out.println("After test method");
    }

}
