package com.edu.sedc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class SeleniumBasicHomework {

    String url = "https://www.saucedemo.com/";

    @Test
    public void SeleniumSetUp() {

        WebDriver driver = new ChromeDriver();
        driver.get(url);
        driver.manage().window().maximize();

    }

    @Test(priority = 1)
    public void testLoginAndPrintHeader() {
        // Navigate to the website
        WebDriver driver = new ChromeDriver();
        driver.get(url);
        driver.manage().window().maximize();

        // Log in with standard_user credentials
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        // Print the header of the page Swag Labs
        WebElement header = driver.findElement(By.className("app_logo"));
        System.out.println("Header of the page Swag Labs: " + header.getText());
    }

    @Test(priority = 2)
    public void testAddToCartAndCheckout() throws InterruptedException {
        // Navigate to the website (already logged in)
        WebDriver driver = new ChromeDriver();
        driver.get(url);
        driver.manage().window().maximize();


        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        Thread.sleep(3000);

        // Add a product to cart
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

        // Go to the cart
        driver.findElement(By.id("shopping_cart_container")).click();

        // Click checkout button
        driver.findElement(By.id("checkout")).click();

        // Enter First Name, Last Name, and Zip postal code
        driver.findElement(By.id("first-name")).sendKeys("standard_user");
        driver.findElement(By.id("last-name")).sendKeys("secret_sauce");
        driver.findElement(By.id("postal-code")).sendKeys("12345");
        driver.findElement(By.id("continue")).click();
    }

        @Test
    public void tearDown() {

        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/inventory.html");
        driver.manage().window().maximize();
        driver.quit();
    }
    private void login(String username, String password) {

        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/inventory.html");
        driver.manage().window().maximize();

        driver.findElement(By.id("user-name")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.id("login-button")).click();
    }
}






