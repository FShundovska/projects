package com.edu.sedc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class AssertionsInSelenium {
    WebDriver driver;
    SoftAssert softAssert = new SoftAssert();

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("https://computer-database.gatling.io/computers");
        driver.manage().window().maximize();
    }

    @AfterMethod
    public void teatDown() {
        driver.quit();
    }

    @Test
    public void hardAssertions() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        String title = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Computer database"))).getText();
        Assert.assertEquals(title, "Computer database");

        boolean isAddComputerButtonDisplayed = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("add"))).isDisplayed();
        Assert.assertTrue(isAddComputerButtonDisplayed);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("add"))).isDisplayed();
    }

    @Test
    public void softAssertions() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        String title = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Computer database"))).getText();

        softAssert.assertEquals(title, "Computer database");

        String totalComputers = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='main']/h1"))).getText();
        softAssert.assertEquals(totalComputers, "574 computers found");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("add"))).isDisplayed();

        softAssert.assertAll();


    }
}

