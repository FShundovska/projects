package com.edu.sedc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.List;

public class SeleniumCommands {

    String url ="https://computer-database.gatling.io/computers";

    @Test
    public void basicSeleniumCommands(){

        WebDriver driver = new ChromeDriver();

        driver.get(url);
        driver.manage().window().maximize();

        //Find Elements
        driver.findElements(By.xpath("//*[@id='pagination']/ul/li/a")).get(2).click();

    }

    @Test
    public void readibilityOfSeleniumCommands() throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.get(url);
        driver.manage().window().maximize();

        /*WebElement searchInput = driver.findElement(By.id("searchbox"));
        searchInput.sendKeys("My computer");
        Thread.sleep(3000);
        searchInput.clear();*/

        /*List <WebElement> paginationButtons = driver.findElements(By.xpath("//*[@id='pagination']/ul/li/a"));
        paginationButtons.get(2).click();*/


        String pageTitle= driver.findElement(By.xpath("//section [@id='main']/h1")).getText();
        System.out.println(driver.findElement(By.xpath("//section [@id='main']/h1")).getText());
        System.out.println(pageTitle);





    }



}
