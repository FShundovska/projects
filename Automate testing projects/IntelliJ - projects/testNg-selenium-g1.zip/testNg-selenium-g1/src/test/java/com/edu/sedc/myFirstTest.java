package com.edu.sedc;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class myFirstTest {

    @Test
    public void basicSeleniumTest(){
        //Instancirajne na samiot web driver
        WebDriver driver = new ChromeDriver();

        //Navigiranje na nekoja strana(google.com)
        driver.get("https://youtube.com");

        //sakame da go zgolemime prozorecot na full screen
        driver.manage().window().maximize();

        //zatvaranje na browserot
        driver.quit();

    }

}
