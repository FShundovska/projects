package com.edu.sedc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SeleiumExercises {

    String url = "https://computer-database.gatling.io/computers";

    @Test
    public void SeleniumExercises() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get(url);
        driver.manage().window().maximize();

        driver.findElement(By.id("add")).click();
        driver.findElement(By.id("name")).sendKeys("TestComputer");
        driver.findElement(By.id("introducer")).sendKeys("2024-02-28");
        driver.findElement(By.id("discontinued")).sendKeys("2025-05-05");
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@type='submit']")).click();


    }

}
