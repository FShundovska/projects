package com.edu.sedc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

public class WaitsAndAssertionsInSelenium {


    @Test
    public void waitsInSelenium(){

        WebDriver driver = new ChromeDriver();
        driver.get("https://demoqa.com/dynamic-properties");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.id("visibleAfter")).click();
        driver.quit();

        //driver.findElement(By.id("visibleAfter")).click();
        driver.findElement(By.id("enableAfter")).click();
        driver.quit();
    }

    @Test
    public void explicitWaitsInSelenium(){
        WebDriver driver = new ChromeDriver();
        driver.get("https://demoqa.com/dynamic-properties");
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("enableAfter"))).click();
        driver.quit();
    }

    @Test
    public void threadSleepMethod() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://demoqa.com/dynamic-properties");
        driver.manage().window().maximize();
        Thread.sleep(10000);
        driver.findElement(By.id("enableAfter")).click();
        driver.quit();
    }



}
