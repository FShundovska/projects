package com.edu.sedc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SeleniumLocators {

    @Test
    public void seleniumLocatorByUsingAttributes() {

        WebDriver driver = new ChromeDriver();

        driver.get("https://computer-database.gatling.io/computers");

        //Finding elements by Id

        driver.findElement(By.id("searchbox"));

        //Finding element by Name

        driver.findElement(By.name("f"));

        //Finding element by className

        driver.findElement(By.className("btn"));

        //Find element by Tag

        driver.findElement(By.tagName("input"));

        //Find element by Link Text

        driver.findElement(By.linkText("Computer database"));

        //Find element by PArtial Link Text

        driver.findElement(By.partialLinkText("puter dat"));

    }

    @Test
    public void seleniumCssSelectors() {

        WebDriver driver = new ChromeDriver();
        driver.get("https://computer-database.gatling.io/computers");

        //By Id
        driver.findElement(By.cssSelector("#searchbox"));

        //By Class Name
        driver.findElement(By.cssSelector(".computers"));

        //By Tag and Id
        driver.findElement(By.cssSelector("input#searchbox"));

        //by tag and call
        driver.findElement(By.cssSelector("input.btn"));

        //by tag and attribute
        driver.findElement(By.cssSelector("input[name=f"));

        //by tag, class and attribute
        driver.findElement(By.cssSelector("input.btn[type=submit]"));

        //Start with
        driver.findElement(By.cssSelector("input[type^=sub]"));

        //Ends with
        driver.findElement(By.cssSelector("input[type$=mit]"));

        //Contains
        driver.findElement(By.cssSelector("input[type*=bm]"));

        //Child elements
        driver.findElement(By.cssSelector("ul li:nth-of-type(1)>a"));

        //Finding the last element in a list of Elements
        driver.findElement(By.cssSelector("ul li:last-child"));

        //Finding the first element in a list of Elements
        driver.findElement(By.cssSelector("ul li:first-child"));

    }
    
    @Test
    public void seleniumXPaths(){

        WebDriver driver = new ChromeDriver();

        driver.get("https://computer-database.gatling.io/computers");

        //navigating through parent/child elements
        driver.findElement(By.xpath("//div[@id='actions']/form/a"));

        //multiple elements that are on the same level
        driver.findElement(By.xpath("//div[@id='pagination']/ul/li[1]"));

        //using text
        driver.findElement(By.xpath("//a[text()='Add a new computer']"));

        //using * as a wild card replaces any kind of Tag
        driver.findElement(By.xpath("//*[text()='Add a new computer']"));

        //Contains
        driver.findElement(By.xpath("//a[contains(@class,'btn')]"));

        //AND & OR
        driver.findElement(By.xpath("//*[@id='searchbox' or @name='f']"));
        driver.findElement(By.xpath("//*[@id='searchbox' and @name='f']"));

        //starts with
        driver.findElement(By.xpath("//input[starts-with(@type,'sea')]"));

        //traversing from child to parent elements
        driver.findElement(By.xpath("//input[@id='searchbox']/../../../table"));















    }


}

