package com.edu.sedc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Vezba {

    @Test
    public void Vezba(){

        WebDriver driver = new ChromeDriver();
        driver.get("https://computer-database.gatling.io/computers");

        driver.findElement(By.tagName("section"));


    }




}
