package com.edu.sedc.tests;

import org.testng.annotations.Test;

public class ButtonsTests extends BaseTest{

    @Test
    public void testButtonsPage () throws InterruptedException {
        buttonsPage.navigateToButtonsPage();
        buttonsPage.clickDoubleButton();
        Thread.sleep(3000);
        buttonsPage.clickContextClick();
        Thread.sleep(3000);
    }
}
