package com.edu.sedc.tests;

import com.edu.sedc.pages.*;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;

public class BaseTest {

    public WebDriver driver;
    public WebDriverWait wait;

    public CheckBoxPage checkBoxPage;

    public SelectMenuPage selectMenuPage;

    public RadioButtonPage radioButtonPage;

    /*public StudentName studentName;
    public StudentEmail studentEmail;
    public StudentGender studentGender;
    public StudentMobile studentMobile;
    public StudentAddress studentAddress;
    public SubjectForStudies subjectForStudies;
    public StudentHobbies studentHobbies;
    public StateAndCity stateAndCity;*/
    public Frames frames;
    public ButtonsPage buttonsPage;
    JavascriptExecutor js;


    final String BASE_URL = "https://demoqa.com/";
    final String RadioButtonUrl = "https://demoqa.com/radio-button";

    private int duration = 10;

    @BeforeMethod
    public void setUp(){
        ChromeOptions options = new ChromeOptions();
        //options.addArguments("--headless");
        options.addArguments("--start-maximized", "--incognito");
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(duration));
        js = (JavascriptExecutor) driver;
        checkBoxPage = new CheckBoxPage(driver, wait);
        /*selectRadioButton = new SelectRadioButton(driver, wait);*/
        selectMenuPage = new SelectMenuPage(driver, wait);
        radioButtonPage = new RadioButtonPage(driver, wait);
        buttonsPage = new ButtonsPage(driver, wait);
        /*studentName = new StudentName (driver, wait);
        studentEmail = new StudentEmail (driver, wait);
        studentMobile = new StudentMobile (driver, wait);
        studentAddress = new StudentAddress (driver, wait);
        subjectForStudies = new SubjectForStudies (driver, wait);
        studentHobbies = new StudentHobbies (driver, wait);
        stateAndCity = new StateAndCity (driver, wait);*/
        frames = new Frames(driver, wait);

        driver.get(BASE_URL);
        //driver.manage().window().maximize();
    }

    @AfterMethod
    public void tearDown(){
        driver.quit();
    }

}
