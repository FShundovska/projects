package com.edu.sedc.utils;

import org.testng.annotations.DataProvider;

public class DataForElements {

    @DataProvider(name="data-for-textbox")
    public Object[][] dataTextBoxObject(){
        return new Object[][] {{"Fani Shundovska", "mail@mail.com", "Address1","Address2"},
                               {"John Doe", "john@mail.com", "Address3","Address4"},
                               {"Max Musterman", "max@mail.com","Address 5", "Address6"}
        };
    }
}
