package com.edu.oop.inheritance;

public class Animal {

    void eat(){
        System.out.println();
    }

}
