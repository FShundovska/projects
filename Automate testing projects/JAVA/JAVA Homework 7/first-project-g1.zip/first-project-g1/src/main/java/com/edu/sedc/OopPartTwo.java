package com.edu.sedc;

public class OopPartTwo {

    public static void main(String[] args) {

        /*So metodata lenght nie broime karakteri vo metodatat String
        String name = "Fani";
        System.out.println(name.length());*/

        /*String text = "Hello World";
        System.out.println(text.toUpperCase()); // konveritra vo golemi bukvi
        System.out.println(text.toLowerCase()); // konvertira vo mali bukvi*/

        /*String fullName = "Hans Bans Musterman"; //IndexOf
        System.out.println(fullName.indexOf('a'));*/

        /*Replace
        String x = "oxoxoxox";
        System.out.println(x.replace('x', 'A'));*/

        //Substring

        /*String y = "0123456789";
        System.out.println(y.substring(3));
        System.out.println(y.substring(3,6));*/

        //EqualsIgnoreCase

        /*String word = "Exit";
        System.out.println(word.equalsIgnoreCase("EXIT"));
        System.out.println(word.equalsIgnoreCase("Tixe"));*/

        //Contains

        /*String z = "Java is programming language";
        System.out.println(z.contains("Java"));
        System.out.println(z.contains("Amit"));*/

        //Concatenation + , concat

        /*String firstName = "Joe";
        String lastName = "Doe";
        System.out.println(firstName+ " " +lastName);

        System.out.println(firstName.concat(" ").concat(lastName));*/

        /*String sentence = "We refer to him as a \"friend\" ";
        System.out.println(sentence);*/

        /*System.out.println("Hello\nWorld");
        System.out.println("Hello\rWorld");
        System.out.println("Hello\tWorld");*/


        //Aritmeticki operacii

        //modulus

        /*int x = 10;
        int z = 3;

        System.out.println(x%z); // Ostatokot pri delenje na vrednostite

        int a = 10;
        System.out.println(++a);
        System.out.println(a); //inkrementiranje ili zgolemuvanje za 1

        int b = 12;
        System.out.println(--b); //dekrementiranje ili namaluvanje za 1
        System.out.println(b);*/

        //Assignement operators
        /*int x = 5;
        x = x+5;
        System.out.println(x);

        int y = 2;
        y+=2;
        System.out.println(y);*/

        //Comparison operators
        /*System.out.println(2==3);

        int x = 20;
        int y = 35;

        System.out.println(x<y);*/

        //Logical Operators

        /*int x =2;
        boolean izraz = x<5 && x==10;
        System.out.println(izraz);
        System.out.println(x<5 && x<10);

        System.out.println(x<5 || x ==10);


        int a = 10;

        System.out.println(!(a>5 && a<99));*/


    }
}
