package com.edu.sedc.JavaHomework7;

public class MainShirt {

    public static void main(String[] args) {

        Shirt myShirt = new Shirt("Black", 'M');

        System.out.println("Color: " + myShirt.getColor());
        System.out.println("Size: " + myShirt.getSize());


    }
}

