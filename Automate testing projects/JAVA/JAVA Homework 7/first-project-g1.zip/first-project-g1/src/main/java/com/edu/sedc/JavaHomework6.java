package com.edu.sedc;

import java.util.Scanner;

public class JavaHomework6 {

    /*//Question1
    static void greetUser(String name) {
        System.out.println("Hello, " + name + "!");
    }*/

    /*//Question 2
    public static int performOperation(int x, int y, int z) {
        // Let's calculate the sum of x, y, and z
        return x + y + z;
    }

    public static double performOperation(double x, double y, double z) {
        return x * y * z;
    }*/

    /*//Question 3
    double[] myArray = { 10.5, 20.0, 15.3, 8.7, 12.1 };
    double average = calculateAverage(myArray);

    private double calculateAverage(double[] myArray) {
        return 0;
        System.out.println("The average value of the array is: " + average);
    }*/

    public static int[] countOdds(int[] numbers) {
        int countOdds = 0;
        for (int number : numbers) {
            if (number % 2 != 0) {
                countOdds++;
            }
        }
        int[] odds = new int[countOdds];
        int index = 0;
        for (int number : numbers) {
            if (number % 2 != 0) {
                odds[index] = number;
                index++;
            }
        }
        return odds;
    }




public static void main(String[] args){

        /*//Question 1 - result
        greetUser("Fani");*/

        /*//Question2 - result
        int intResult = performOperation(5, 10, 3);
        double doubleResult = performOperation(2.5, 3.0, 1.2);

        System.out.println("Integer result: " + intResult);
        System.out.println("Double result: " + doubleResult);*/

        /*//Question 3 - result
        public static double calculateAverage(double[] arr) {

        double sum = 0.0;
        for (double num : arr) {
            sum += num;
        }
        return sum / arr.length;*/


    }
}
