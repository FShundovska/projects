package com.edu.oop.inheritance;

public class Dog extends Animal {

    public void bark() {
        System.out.println("Barking");
    }

}
