/*package com.edu.oop.inheritance;

public class Exersizes {

   public static void main(String[] args) {

        MathOperations mathOps = new MathOperations();
        double dividend = 10.0;
        double divisor = 2.0;


        double quotient = mathOps.division(dividend, divisor);
        System.out.println("Result of division: " + quotient);


        double product = mathOps.multiplication(dividend, divisor);
        System.out.println("Result of multiplication: " + product);


    }
}*/



/*public static void main(String[] args){

    MathOperations matematika= new MathOperations();
    double ime= matematika.podeleno(5,9);
    System.out.println(matematika.podeleno(4,8));
    System.out.println(ime);
    System.out.println(MathOperations.pomnozeno(3,9));
}
}*/
