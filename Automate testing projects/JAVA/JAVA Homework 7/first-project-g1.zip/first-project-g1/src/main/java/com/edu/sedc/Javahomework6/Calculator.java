package com.edu.sedc.Javahomework6;

public class Calculator {

    public static void main(String[] args) {

        double[] values = { 10.5, 20.0, 15.3, 8.7, 12.1 };

        double average = calcAverage(values);

        System.out.println("The average value is: " + average);
    }

    public static double calcAverage(double[] array) {
        double sum = 0.0;
        for (double value : array) {
            sum += value;
        }
        return sum / array.length;
    }
}

