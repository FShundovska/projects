package com.edu.sedc;

public class JavaHomework4 {
    public static void main(String[] args) {

        /*String month = String.valueOf(7);
        switch (Integer.parseInt(month)) {
            case 1:
                System.out.println("January");
                break;
            case 2:
                System.out.println("February");
                break;
            case 3:
                System.out.println("March");
                break;
            case 4:
                System.out.println("April");
                break;
            case 5:
                System.out.println("May");
                break;
            case 6:
                System.out.println("June");
                break;
            case 7:
                System.out.println("July");
                break;
            case 8:
                System.out.println("August");
                break;
            case 9:
                System.out.println("September");
                break;
            case 10:
                System.out.println("October");
                break;
            case 11:
                System.out.println("November");
                break;
            case 12:
                System.out.println("December");
                break;
            default:
                System.out.println("Invalid input");
                break;
        }*/


        /*for(int a=10; a>=0; a--){
            System.out.println(a);
        }*/

        /*for (int count = 10; count > 0; count--) {
            System.out.println(count);
        }*/

        /*for (int i = 1; i <= 15; i++) {
            System.out.println(i);
        }*/

        /*for (int i = 5; i <= 100; i += 5) {
            System.out.println(i);
        }*/

        /*for (int index = 0; index < 5; index++) {
            if (index == 2) {
                break;
            }
            System.out.println(index);
        }*/






    }
}
