package com.edu.sedc;

public class Arrays {
    public static void main(String[] args) {
        //Prv nacin za kreiranje na niza
        /*String [] cars= {"Volvo", "BMW", "Ford", "Mazda"};
        System.out.println(cars[2]);

        cars[2]="Toyota";
        System.out.println(cars[2]);

        //Vtor nacin za kreiranje na niza
        int[] broevi = new int [4];
        broevi[0]=22;
        broevi[1] =33;
        broevi[2]=44;
        broevi[3]=55;

        System.out.println(broevi[3]);*/

        /*String [] cities = {"Tokyo", "Berlin", "Skopje", "Sofija", "Beograd"};
        /*System.out.println(cities.length);*/ //gi broi elementite vo nizata
        // broj na element =0,1,2, 3, 4  broj na element so length =1, 2, 3, 4, 5
        /*for (int i =0; i < cities.length; i++) {
            System.out.println(cities[i]);
        }*/

        //ForEach ciklus - specificiran koga se raboti so nizi
        /* for(String city:cities){
            System.out.println(city);
        }*/

        // Multidimenzionalni nizi

        /*int [][] myNumbers = { {1,2,3,4}, {5,6,7}, {8,9,10}};
        int x =myNumbers [2][1];
        System.out.println(x); //Outputs 7*/

//Exercise 1

        /*int[] x = {1, 2, 3,};
        int sum = 0;
        for (int i = 0; i < x.length; i++) {
            sum += x[1];
        }
            System.out.println(sum);*/
//Exercise 2

        /*int[] x = {1, 2, 3, 4, 5, 1};
        int sum = 0;
        double average;
        for (int i = 0; i < x.length; i++) {
            sum += x[1];
        }
        average = (double) sum / x.length;

        System.out.println("The average is " + average);*/


        /*int [][] myNumbers = { {1,2,3,4}, {5,6,7}, {8,9,10}};
        int x =myNumbers [2][1];
        System.out.println(x);*/


       /* int[] myNumber = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -1, 11, -2};
        int max = myNumber[0];
        int min = myNumber[0];
        for (int i = 0; i < myNumber.length; i++) {
            if (myNumber[i] > max) {
                max = myNumber[i];
            }
            if (myNumber[i] < min) {
                min = myNumber[i];
            }
            System.out.println("Biggest number is "+max")";
                    System.out.println ("Smallest Number is "+min");*/

            /*int [] broevi = {1,2,3,4,5,-1,6,-2};
            int max  = broevi[0]; //1, 2, 3,4,5,6
            int min = broevi[0]; //1, -1, -2

            for (int i =0;i<broevi.length;i++){
            if (broevi[i]>max){
            max = broevi[i];
            }
            if (broevi[i]<min){
            min= broevi[i];
             }
         }

        System.out.println("The biggest number is "+max);
        System.out.println("The smallest number is " + min);*/

        /*int[] oddNumbers = {10, 20, 30, 40, 50};
                for (int i = 0; i < oddNumbers.length; i++) {
            if (oddNumbers[i] % 2 != 0) {
                System.out.println(oddNumbers[i]);
            }

        }*/


        /*int[] broevi = {10, 20, 30, 40, 50};
        if (broevi.length >= 1) {
            boolean result = broevi[0] == broevi[broevi.length - 1];
            System.out.println("The first and last elements are the same: " + result);
        } else {
            System.out.println("The array is empty.");
        }*/




    }
}






