package com.edu.sedc.JavaHomework7.package1question1;
public class Access1 {
    private int package1Variable;
    public int allClassesVariable;
    private int access1Variable;

    public Access1() {
        package1Variable = 10;
        allClassesVariable = 20;
        access1Variable = 30;
    }

     public int getAccess1Variable() {
        return access1Variable;
    }
}
