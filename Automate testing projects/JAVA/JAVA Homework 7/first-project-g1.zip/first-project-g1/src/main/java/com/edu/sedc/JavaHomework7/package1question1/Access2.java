package com.edu.sedc.JavaHomework7.package1question1;

public class Access2 {

    public static void main(String[] args) {

        Access1 access1O = new Access1();
        System.out.println("Value of allClassesVariable: " + access1O.allClassesVariable);


    }
}
