package com.edu.oop.inheritance;

public class StudentExersize {

        /*String[] names = {"Ana", "Biljana", "Daniela", "Ema"};
        Student.listStudentsWith3Letters(names);*/

}

