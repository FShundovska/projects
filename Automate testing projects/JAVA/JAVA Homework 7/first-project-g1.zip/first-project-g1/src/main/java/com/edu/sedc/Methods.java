package com.edu.sedc;

public class Methods {

    /*public static void printMyFullName(){
        System.out.println("John Doe");
    }*/

    /*protected static void printStudentNAme(String studentName){
        System.out.println(studentName);
    }*/

    //Return types
    /*public static String singleWord(){
        return "Hello";
    }*/

    /*static int  plusMethod (int x, int y) {
        return x+y;
    }*/
    /*static double plusMethod (double x, double y) {
        return x+y;
    }*/

    /*private static int sumOfTwoNumbers(int x, int y){
        return x+y;
    }*/

    /*static int sumOfTwoOtherNumbers(){
        return 10+5;
    }*/

    //exr 1
    /* public static void printMyCredentialsAndAge(String firstName, String lastName, int age){
        System.out.println("Fanka Shundovska");
        System.out.println(52);;
    }*/

    //Natasa
    /*public static String fullNameAndAge(String firstName, String lastName, int age) {
        return firstName + lastName + age;
    }*/
    /*System.out.println(fullNameAndAge("Natasha ","Antovska ",24));
    System.out.println(fullNameAndAge("Elena ","Antovska ",20)); */

    //Verica
    /*public static String printData (String firstName, String lastName, int age) {
        return (firstName + " " + lastName + ", " + age );
    }*/

    /*System.out.println(printData("Verica", "Gjorgjeska", 30));*/

    //Exr 2 - Create a method that will print the number range from 1 to a number
    //of your choice.

    /*public static void numberRange (int number){
        for (int i=1; i<=number; i++){
            System.out.println(i);
        }
    }*/

    //Exr 3 Write a method to evaluate if a number is positive or negative.

    /*public static void number(int number){
        if (number>=0){
            System.out.println("Number is positive");
        }
        else {
            System.out.println("Number is negative");
        }
    }*/

    private static boolean isNumberPositive(int number){
        return number>0;
    }

    /*static void retunrOddNumbers(int [] numbers){
        for (int i = 0; i<numbers.length;i++){
            if (numbers[i]%2!=0){
                System.out.println(numbers[i]);
            }
        }
    }

    static void returnEvenNumbers(int [] numbers){
        for (int i =0;i<numbers.length;i++){
            if (numbers[i]%2==0){
                System.out.println(numbers[i]);
            }
        }*/

    public static void main(String[] args) {
       /* System.out.println("John Doe");
        printMyFullName();
        System.out.println("John Doe");
        System.out.println("John Doe");
        System.out.println("John Doe");
        System.out.println("John Doe");
        printMyFullName();
        printMyFullName();
        printMyFullName();*/
        /*printMyFullName();
        String word = singleWord();
        int sum = sumOfTwoNumbers();
        System.out.println(singleWord());
        System.out.println(sumOfTwoNumbers());
        System.out.println(sumOfTwoOtherNumbers());*/

        /*System.out.println(sumOfTwoNumbers(2, 3));
        System.out.println(sumOfTwoNumbers(5, 10));
        System.out.println(sumOfTwoNumbers(100, 200));*/

        /*printStudentNAme("Sanja");
        printStudentNAme("Fanka");
        printStudentNAme("Aleksandar");*/

       /* printMyCredentialsAndAge(); */

        /*System.out.println(plusMethod(6, 5));
        System.out.println(plusMethod(2.5, 3.2));*/

        /*numberRange(15);*/

        //so koristenje varijabli
        //System.out.println(word);
        //System.out.println(sum);
        //"Hello"; == singleWord()
        //2+3 ==sumOfTwoNumbers()



    }
}
