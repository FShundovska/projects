package com.edu.sedc.JavaHomework7;

public class MainCalculator {

    public static void main(String[] args) {

        Calculator calculator = new Calculator();

        int num1 = 10;
        int num2 = 5;

        System.out.println("Addition: " + Calculator.addMethod(num1, num2));
        System.out.println("Subtraction: " + Calculator.subMethod(num1, num2));
        System.out.println("Multiplication: " + calculator.mulMethod(num1, num2));
        System.out.println("Division: " + calculator.divMethod(num1, num2));
    }

}
