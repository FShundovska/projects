package com.edu.oop.inheritance;

public class Person {
        private String firstName;
        private String lastName;

        public Person() {
            firstName = "Fani";
            lastName = "Shundovska";
        }
        public Person(String firstName, String lastName) {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public void printFullName() {
            System.out.println("Full Name: " + firstName + " " + lastName);
        }
}
