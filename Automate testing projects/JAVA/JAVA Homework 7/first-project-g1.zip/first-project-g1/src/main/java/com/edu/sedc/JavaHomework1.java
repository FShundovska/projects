package com.edu.sedc;

public class JavaHomework1 {

    public static void main(String[] args) {

        /*String message = "Hello World";
        System.out.println(message);*/

      /*Single-line comments start with //
        Multi-line comments start with /* and end with */

        /*String text = "This is a text variable";
        System.out.println(text);*/

        /*int number = 42;
        System.out.println(number);*/

        /*double pi = 3.14;
        System.out.println(pi);*/

        /*float gravity = 9.81F;
        System.out.println(gravity);*/

        /* char letter = 'A';
        System.out.println(letter); */

        /*boolean isHappy = true;
        System.out.println(isHappy);*/

        /*int age;
        age = 18;
        System.out.println(age);*/

        /*int score;
        score = 10;
        score = 20;
        System.out.println(score);*/

        /*final int max = 100;
        System.out.println(max);*/








    }

}

