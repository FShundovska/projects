package com.edu.oop.inheritance;

public class Evaluacija {

    String name;
    String id;
    double OcenkaMatematika;
    double OcenkaMakedonski;
    double OcenkaIT;

    public void printInfo() {
        System.out.println("Matematika = " + OcenkaMatematika);
        System.out.println("Makedonski = " + OcenkaMakedonski);
        System.out.println("IT = " + OcenkaIT);
        System.out.println("Average = " + average());
    }

    public double average() {
        return (OcenkaMatematika + OcenkaMakedonski + OcenkaIT) / 3;
    }

}
