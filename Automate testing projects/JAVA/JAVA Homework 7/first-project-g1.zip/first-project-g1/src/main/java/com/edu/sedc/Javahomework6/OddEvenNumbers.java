package com.edu.sedc.Javahomework6;

public class OddEvenNumbers {

    public static void main(String[] args) {

        /*int[] numbers = {2, 4, 23, 100, 66, 11, 2602, 36};
        int oddResult = findOddNumber(numbers);
        int evenResult = findEvenNumber(numbers);

        System.out.println("Odd number: " + oddResult);
        System.out.println("Even number: " + evenResult);
    }
    public static int findOddNumber(int[] arr) {
        for (int num : arr) {
            if (num % 2 != 0) {
                return num;
            }
        }
        return -1;
    }
    public static int findEvenNumber(int[] arr) {
        for (int num : arr) {
            if (num % 2 == 0) {
                return num;
            }
        }
        return -1;*/

        int[] numbers = {2, 4, 23, 100, 66, 11, 2602, 36};

        for (int c = 0; c < numbers.length; c++) {
            if (numbers[c] % 2 == 0) {
                System.out.println(numbers[c] + " is even");
            } else {
                System.out.println(numbers[c] + " is odd");
            }
        }
    }
}




