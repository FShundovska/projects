package com.edu.sedc.Javahomework6;
public class MathOperation {

    public static double operation(int x, double y) {
        double result = x * y;
        return result;
    }

    public static void main(String[] args) {
        int x = 5;
        double y = 3.14;
        double z = operation(x, y);

        System.out.println("Result of the operation: " + z);

    }
}
