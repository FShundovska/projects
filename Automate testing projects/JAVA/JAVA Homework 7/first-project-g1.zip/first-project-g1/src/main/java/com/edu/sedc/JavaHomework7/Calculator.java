package com.edu.sedc.JavaHomework7;
public class Calculator {
    public static int addMethod(int a, int b) {
        return a + b;
    }
    public static int subMethod(int a, int b) {
        return a - b;
    }
    public int mulMethod(int a, int b) {
        return a * b;
    }
    public double divMethod(int a, int b) {
        if (b != 0) {
            return (double) a / b;
        } else {
            System.out.println("Error: Division by zero!");
            return Double.NaN;
        }
    }
}
