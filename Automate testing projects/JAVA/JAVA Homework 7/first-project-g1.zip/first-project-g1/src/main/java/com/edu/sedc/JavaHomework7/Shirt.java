package com.edu.sedc.JavaHomework7;

public class Shirt {
    private String color;
    private char size;

    public Shirt(String color, char size) {
        this.color = color;
        this.size = size;
    }
    public String getColor() {
        return color;
    }
     public char getSize() {
        return size;
    }
}

