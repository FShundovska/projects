package com.edu.sedc.Javahomework6;

public class AverageValue {
    public static void main(String[] args) {

        double num1 = 5.0;
        double num2 = 7.0;
        double num3 = 9.0;

        double average = calculateAverage(num1, num2, num3);

        System.out.println("Average value: " + average);
    }
    public static double calculateAverage(double a, double b, double c) {
        return (a + b + c) / 3.0;

    }
}
