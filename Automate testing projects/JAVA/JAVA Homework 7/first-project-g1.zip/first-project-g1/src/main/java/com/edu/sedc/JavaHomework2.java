package com.edu.sedc;

public class JavaHomework2 {
    public static void main(String[] args) {

        /*String text = "They decided to go on a road trip across the country and visit many places.";
        text = text.replace('o', 'O');
        System.out.println(text); */

        /*String text = "Java is one of the most commonly used programming languages";
        int start = text.indexOf("most");
        int end = start + 4;
        String word = text.substring(start, end);
        System.out.println(word);*/

        /*String name = "Fani";
        String occupation = "QA Engineer";
        String hobby = "exploring new ways of generating imaginative and innovative contents";
        String sentences = "My name is " + name + ". I am " + occupation + ". I enjoy " + hobby + ".";
        System.out.println(sentences);*/

        /*int num1 = 10;
        int num2 = 5;
        int result = num1 + num2;
        System.out.println(result);*/

        /*int x = 20;
        int y = 15;
        int z = x - y;
        System.out.println(z);*/

        /*String txt = "Hello Everybody";
        int index = txt.indexOf("e");
        System.out.println(index);*/

        /*int product = 10 * 5;
        System.out.println(product);*/

        /*int quotient = 10 / 5;
        System.out.println(quotient);*/

        /*type: integer -primitive
                byte - primitive
                float - primitive
                double - primitive
                string - non-primitive
                array - non-primitive*/









    }
}
