package com.edu.sedc;

public class Loops {

    public static void main(String[] args) {

        /*int i = 0;
        while (i<=5) {
            System.out.println(i);
            i++;
        }

        System.out.println("The value of i is " + i);*/

        /*int i = 11;
        while (i<=10){
            if (i==5){
                //i+=2;
                break;
            }
            System.out.println(i);
            i++;

        }

        System.out.println("The value of 1 is " + i);*/

        /*int y = 1;
        while (y<=10){
            if(y==5){
                //y++;
                continue;
            }
            System.out.println(y);
            y++;

        }*/

        /*//DO-WHILE
        int i = 0;
        do {
            System.out.println(i);
            i++;
        } while (i<5);

        System.out.println("The value of i is " +i);*/

        //FOR LOOP
        /*for (int i =0; i <5; i++){
            System.out.println(i);*/

        /*int i = 0;
        while (i<=10) {
            System.out.println(i);
            i++;
        }*/

        /*for(int a=10; a>=1; a--;){
        System.out.println(a);
        }*/

        /*int i = "a";
        while (i<="z") {
            System.out.println(i);
            i++;
        }*/

        /*char = "a"
        for (char A = "a"; A <= "z"; A++) {
            System.out.println(A);
        }*/


        /*int sum = 0; //1,3, 6, 10
        for (int i = 1; i <= 5; i++) {
            sum+=i;
            System.out.println(sum);
        }

        System.out.println("The sum of number is "+sum);*/

        /*int sum = 0;

        for (int i = 1; i <= 10; i++) {
            if (i % 2 == 0) {
                sum = sum + i;
            }
        }
        System.out.println("The sum of all even numbers between 1 to 10 is " + sum);*/

        /*int sum = 0;
        for (int i = 2; i <= 10; i += 2) {
            sum += i;
        }
        System.out.println("The sum of all even numbers between 1 to 10 is " + sum);*/






    }
}

