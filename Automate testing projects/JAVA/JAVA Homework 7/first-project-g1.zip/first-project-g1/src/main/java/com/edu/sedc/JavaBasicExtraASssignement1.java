package com.edu.sedc;

public class JavaBasicExtraASssignement1 {
    public static void main(String[] args) {

        /*String text = "Test automation with Java";
        int start = text.indexOf("automation");
        int end = start + 10;
        String word = text.substring(start, end);
        System.out.println("automation");*/

        /*int x, y, z;
        x = 10;
        y = 20;
        z = y - x;
        System.out.println(z);
        z = z * 3;
        System.out.println(z);*/

        /*String firstName = "John";
        String lastName = "Doe";
        int age = 30;
        //System.out.println("My full name is: " + firstName + " " + lastName);
        //System.out.println("I have " + age + " years");
        System.out.println("My full name is: " + firstName + " " + lastName +"." + "\nI am " + age + " years old.");*/


        /*String sentence = "Selenium is one of the most used testing frameworks";
        int index = sentence.indexOf("Selenium");
        System.out.println(index);*/


        /*double x = 35;
        double y = 2;
        double result = x;
        while (result - y >= 0) {
            result = result - y;
        }
        System.out.println(result);*/

        /*double x = 35; double y = 2;
        int result = (int) (x % y);
        System.out.println(result);*/


    }
}
