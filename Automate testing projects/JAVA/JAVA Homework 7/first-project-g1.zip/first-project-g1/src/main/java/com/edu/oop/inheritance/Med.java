package com.edu.oop.inheritance;

public class Med {


    class Cvet {
        void cveta () {
            System.out.println("Rozata cveta");
        }
    }

}
