package com.edu.oop.inheritance;

public class Cvet {

    public void polen () {
        System.out.println("Cvetot ima polen");
    }
}
