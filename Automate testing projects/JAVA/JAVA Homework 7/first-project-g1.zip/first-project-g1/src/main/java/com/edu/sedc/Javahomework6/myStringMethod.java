package com.edu.sedc.Javahomework6;

public class myStringMethod {

    public static void printName(String name) {
        System.out.println("Hello, " + name + "!");
    }
}


