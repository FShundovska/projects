package com.edu.sedc;

public class JavaExtraHomework2 {

    public static void main(String[] args) {

        /*int enterANumber;
        System.out.println("Enter a number:");

        int number = 7;
        if (number > 0) {
            System.out.println("The number is positive.");
        } else if (number < 0) {
            System.out.println("The number is negative.");
        } else {
            System.out.println("The number is zero.");
        }*/

        /*int x = 10;
        int y = 5;
        if (x > y) {
            System.out.println("x is bigger than y");
        } else if (x < y) {
            System.out.println("x is smaller than y");
        } else {
            System.out.println("x and y are the same");
        }*/

       /*java.util.Scanner scanner = new java.util.Scanner(System.in);

        System.out.println("Enter an integer between 1 and 7:");

        String text ="SMondayN";
        System.out.println(text.substring(1,7));*/


       /*int day = 7;
        switch (day) {
            case 1:
                System.out.println("Monday");
                break;
            case 2:
                System.out.println("Tuesday");
                break;
            case 3:
                System.out.println("Wednesday");
                break;
            case 4:
                System.out.println("Thursday");
                break;
            case 5:
                System.out.println("Friday");
                break;
            case 6:
                System.out.println("Saturday");
                break;
            case 7:
                System.out.println("Sunday");
                break;
            default:
                System.out.println("Invalid input");
                break;
        }*/

        /*int x = 9;
        int y = 3;

        if (x > y) {
            System.out.println("x is bigger than y by " + (x - y));
        } else if (x < y) {
            System.out.println("x is smaller than y by " + (y - x));
        } else {
            System.out.println("x and y are the same, so the difference is zero");
        }*/

    }

}



