package com.edu.oop.inheritance;

public class VezbaPcela {
    public static void main(String[] args) {


        Cvet Roza = new Cvet ();
        Roza.polen();

        Pcela Vili = new Pcela();
        Vili.leta();
        Vili.polen();



    }
}
