package com.edu.sedc.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EndToEndPages {

    WebDriver driver;
    WebDriverWait wait;

    public EndToEndPages(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;

    }


    private By userNameInput = By.id("user-name");
    private By passwordInput = By.id("password");
    private By loginButton = By.id("login-button");
    private By addBackpack = By.id("add-to-cart-sauce-labs-backpack");
    private By addBikeLight = By.id("add-to-cart-sauce-labs-bike-light");
    private By shoppingContainer = By.id("shopping_cart_container");
    private By checkout = By.id("checkout");
    private By firstNameInput = By.id("first-name");
    private By lastNameInput = By.id("last-name");
    private By zipCodeInput = By.id("postal-code");
    private By continueButton = By.id("continue");
    private By finishButton = By.id("finish");

    private By orderTextDisplayed = By.className("complete-header");
    public void navigateToLoginUrl() {
        driver.navigate().to("https://www.saucedemo.com/");
    }

    public void enterUserName(String userName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(userNameInput)).sendKeys(userName);

    }

    public void enterPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordInput)).sendKeys(password);
    }

    public void clickLoginButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginButton)).click();

    }

    public void clickAddBackPack() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addBackpack)).click();


    }

    public void clickAddBikeLight() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addBikeLight)).click();

    }

    public void clickShoppingContainer() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shoppingContainer)).click();

    }

    public void clickCheckOut() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(checkout)).click();

    }

    public void enterFirstName(String fistName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameInput)).sendKeys(fistName);

    }

    public void enterLastName(String lastName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameInput)).sendKeys(lastName);

    }

    public void enterZipCode(String zipCode) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(zipCodeInput)).sendKeys(zipCode);

    }

    public void clickContinue() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(continueButton)).click();


    }

    public void clickFinish() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(finishButton)).click();


    }

    public String getTextFromFinishedOrder() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(orderTextDisplayed)).getText();
    }








}
