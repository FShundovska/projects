package com.edu.sedc.tests;

import com.edu.sedc.pages.EndToEndPages;
import org.testng.Assert;
import org.testng.annotations.Test;

public class EndToEndTests extends BaseTests{

    @Test
    public void endToEnd() throws InterruptedException {

        EndToEndPages endToEndPages = new EndToEndPages(driver, wait);
        endToEndPages.navigateToLoginUrl();
        endToEndPages.enterUserName("standard_user");
        endToEndPages.enterPassword("secret_sauce");
        endToEndPages.clickLoginButton();
        endToEndPages.clickAddBackPack();
        endToEndPages.clickAddBikeLight();
        endToEndPages.clickShoppingContainer();
        endToEndPages.clickCheckOut();
        endToEndPages.enterFirstName("Snezhana");
        endToEndPages.enterLastName("Tachevska");
        endToEndPages.enterZipCode("2000");
        endToEndPages.clickContinue();
        js.executeScript("window.scrollBy(0, 500)", "");
        endToEndPages.clickFinish();


        Assert.assertEquals(endToEndPages.getTextFromFinishedOrder(), "Thank you for your order!");

        Thread.sleep(3000);



    }
}
