package com.edu.sedc.tests;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;

public class BaseTests {

    public WebDriver driver;
    public WebDriverWait wait;
    JavascriptExecutor js;

    final String BASE_URL = "https://www.saucedemo.com/";
    private int duration = 10;

    @BeforeMethod

    public void setUp(){
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(duration));
        js = (JavascriptExecutor) driver;
        driver.get(BASE_URL);
        driver.manage().window().maximize();
    }

    @AfterMethod

    public void tearDown(){
        driver.quit();
    }




}
